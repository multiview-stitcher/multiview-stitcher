import os
import tempfile

import numpy as np
import pytest
import xarray as xr
import zarr

from multiview_stitcher import msi_utils, param_utils
from multiview_stitcher import spatial_image_utils as si_utils


@pytest.mark.parametrize(
    "dims",
    [
        ["y", "x"],
        ["z", "y", "x"],
        ["c", "z", "y", "x"],
        ["t", "c", "y", "x"],
    ],
)
def test_calc_resolution_levels(dims):
    sdims = [dim for dim in dims if dim in si_utils.SPATIAL_DIMS]
    sim = si_utils.get_sim_from_array(
        np.ones((1,) * (len(dims) - len(sdims)) + (202,) * len(sdims)), dims=dims)
    msim = msi_utils.get_msim_from_sim(sim)

    # assert that for each level at least one spatial dimension is downsampled
    previous_shape = si_utils.get_shape_from_sim(sim)
    for scale_key in msi_utils.get_sorted_scale_keys(msim)[1:]:
        current_shape = si_utils.get_shape_from_sim(msim[scale_key])
        downsampled = False
        for dim in si_utils.get_spatial_dims_from_sim(sim):
            if current_shape[dim] < previous_shape[dim]:
                downsampled = True
        assert downsampled
        previous_shape = current_shape

    scale_keys = msi_utils.get_sorted_scale_keys(msim)
    assert len(scale_keys) > 1


def test_update_msim_transforms_zarr():
    msim = msi_utils.get_msim_from_sim(
        si_utils.get_sim_from_array(np.ones((10, 10)))
    )
    affine1 = param_utils.affine_to_xaffine(param_utils.random_affine())
    affine2 = param_utils.affine_to_xaffine(param_utils.random_affine())

    msi_utils.set_affine_transform(msim, affine1, "test_key")

    # overwrite existing transform
    with tempfile.TemporaryDirectory() as tmpdirname:
        msi_utils.multiscale_spatial_image_to_zarr(msim, tmpdirname)
        before_update = msi_utils.multiscale_spatial_image_from_zarr(
            tmpdirname
        )
        msi_utils.set_affine_transform(msim, affine2, "test_key")
        msi_utils.update_msim_transforms_zarr(msim, tmpdirname, overwrite=True)
        after_update = msi_utils.multiscale_spatial_image_from_zarr(tmpdirname)

    ti = msi_utils.get_transform_from_msim(before_update, "test_key")
    tf = msi_utils.get_transform_from_msim(after_update, "test_key")

    # don't overwrite existing transform
    with tempfile.TemporaryDirectory() as tmpdirname:
        msi_utils.multiscale_spatial_image_to_zarr(msim, tmpdirname)
        before_update = msi_utils.multiscale_spatial_image_from_zarr(
            tmpdirname
        )
        msi_utils.set_affine_transform(msim, affine2, "test_key")
        msi_utils.update_msim_transforms_zarr(
            msim, tmpdirname, overwrite=False
        )
        after_update = msi_utils.multiscale_spatial_image_from_zarr(tmpdirname)

    ti = msi_utils.get_transform_from_msim(before_update, "test_key")
    tf = msi_utils.get_transform_from_msim(after_update, "test_key")

    assert np.allclose(ti, tf)

    # check that new transforms are added
    with tempfile.TemporaryDirectory() as tmpdirname:
        msi_utils.multiscale_spatial_image_to_zarr(msim, tmpdirname)
        before_update = msi_utils.multiscale_spatial_image_from_zarr(
            tmpdirname
        )
        msi_utils.set_affine_transform(msim, affine2, "test_key2")
        msi_utils.update_msim_transforms_zarr(
            msim, tmpdirname, overwrite=False
        )
        after_update = msi_utils.multiscale_spatial_image_from_zarr(tmpdirname)

    keys = msi_utils.get_transforms_from_dataset_as_dict(
        after_update["scale0"]
    )
    assert "test_key" in keys
    assert "test_key2" in keys
    assert "image" in after_update["scale0"].data_vars

    # check that existing transforms are kept
    with tempfile.TemporaryDirectory() as tmpdirname:
        msi_utils.multiscale_spatial_image_to_zarr(msim, tmpdirname)
        before_update = msi_utils.multiscale_spatial_image_from_zarr(
            tmpdirname
        )
        msim = msi_utils.get_msim_from_sim(
            si_utils.get_sim_from_array(np.ones((10, 10)))
        )
        msi_utils.update_msim_transforms_zarr(msim, tmpdirname, overwrite=True)
        after_update = msi_utils.multiscale_spatial_image_from_zarr(tmpdirname)

    keys = msi_utils.get_transforms_from_dataset_as_dict(
        after_update["scale0"]
    )
    assert "test_key" in keys
    assert "image" in after_update["scale0"].data_vars


@pytest.mark.parametrize(
    "ndim, origin",
    [
        (2, {"y": 0.0, "x": 0.0}),
        (2, {"y": 5.0, "x": 3.0}),
        (3, {"z": 2.0, "y": 5.0, "x": 3.0}),
    ],
)
def test_correct_multiscale_origins(ndim, origin):
    """
    After correct_multiscale_origins:
    - The scale0 (highest resolution) origin must be unchanged.
    """
    shape = (202,) * ndim
    dims = ["z", "y", "x"][-ndim:]
    spacing = {dim: 0.5 for dim in dims}

    sim = si_utils.get_sim_from_array(
        np.zeros(shape),
        dims=dims,
        scale=spacing,
        translation=origin,
    )
    msim = msi_utils.get_msim_from_sim(sim)
    scale_keys = msi_utils.get_sorted_scale_keys(msim)
    assert len(scale_keys) > 1, "need more than one scale level for this test"

    msim_corrected = msi_utils.correct_multiscale_origins(msim)

    sdims = [dim for dim in dims if dim in si_utils.SPATIAL_DIMS]

    # scale0 origin must be preserved
    sim0 = msi_utils.get_sim_from_msim(msim_corrected, scale="scale0")
    for dim in sdims:
        assert np.isclose(
            sim0.coords[dim].values[0],
            origin[dim],
        ), f"scale0 origin changed for dim {dim}"


def test_get_res_level_from_binning_factors():
    """Test that get_res_level_from_binning_factors returns correct resolution level."""
    # Create a test image with known multiscale structure
    # scale0: 100x100, scale1: 50x50 (factor 2), scale2: 25x25 (factor 4)
    sim = si_utils.get_sim_from_array(
        np.ones((100, 100)),
        dims=["y", "x"],
        scale={"y": 1.0, "x": 1.0},
        translation={"y": 0.0, "x": 0.0},
    )
    
    # Create multiscale with specific factors
    scale_factors = [
        {"y": 2, "x": 2},  # scale1: 50x50
        {"y": 2, "x": 2},  # scale2: 25x25
    ]
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=scale_factors)
    
    # Test case 1: binning factors match scale1 exactly
    scale_key, remaining = msi_utils.get_res_level_from_binning_factors(
        msim, {"y": 2, "x": 2}
    )
    assert scale_key == "scale1"
    assert remaining == {"y": 1, "x": 1}
    
    # Test case 2: binning factors match scale2 exactly
    scale_key, remaining = msi_utils.get_res_level_from_binning_factors(
        msim, {"y": 4, "x": 4}
    )
    assert scale_key == "scale2"
    assert remaining == {"y": 1, "x": 1}
    
    # Test case 3: binning factors less than any scale (use scale0)
    scale_key, remaining = msi_utils.get_res_level_from_binning_factors(
        msim, {"y": 1, "x": 1}
    )
    assert scale_key == "scale0"
    assert remaining == {"y": 1, "x": 1}
    
    # Test case 4: binning factors require additional binning on top of scale1
    # We want binning of 4, and scale1 provides 2, so we need remaining 2
    scale_key, remaining = msi_utils.get_res_level_from_binning_factors(
        msim, {"y": 2, "x": 2}
    )
    assert scale_key == "scale1"
    # Remaining should be 1 since scale1 already gives us factor 2
    assert remaining == {"y": 1, "x": 1}


def test_get_res_level_from_spacing():
    """Test that get_res_level_from_spacing returns the coarsest level whose spacing <= target."""
    # scale0: spacing 1.0, scale1: spacing ~2.0, scale2: spacing ~4.0
    sim = si_utils.get_sim_from_array(
        np.ones((100, 100)),
        dims=["y", "x"],
        scale={"y": 1.0, "x": 1.0},
        translation={"y": 0.0, "x": 0.0},
    )
    scale_factors = [{"y": 2, "x": 2}, {"y": 2, "x": 2}]
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=scale_factors)

    # Requesting exactly scale0 spacing → level 0
    assert msi_utils.get_res_level_from_spacing(msim, {"y": 1.0, "x": 1.0}) == 0

    # Requesting spacing that fits scale1 (>= 2.0) → level 1
    assert msi_utils.get_res_level_from_spacing(msim, {"y": 2.0, "x": 2.0}) == 1

    # Requesting spacing that fits scale2 (>= 4.0) → level 2
    assert msi_utils.get_res_level_from_spacing(msim, {"y": 4.0, "x": 4.0}) == 2

    # Requesting very coarse spacing (larger than any level) → last level
    assert msi_utils.get_res_level_from_spacing(msim, {"y": 100.0, "x": 100.0}) == 2

    # Requesting spacing between scale0 and scale1 → level 0 (scale1 spacing too large)
    assert msi_utils.get_res_level_from_spacing(msim, {"y": 1.5, "x": 1.5}) == 0


def test_get_msim_from_sims_orders_shapes_and_uses_highest_res_transforms():
    # Pass the lower-resolution sim first to check that the helper reorders levels.
    sim_hi = si_utils.get_sim_from_array(
        np.ones((100, 100)),
        dims=["y", "x"],
        affine=param_utils.affine_from_translation([1, 2]),
        transform_key="hi",
    )
    sim_lo = si_utils.get_sim_from_array(
        np.ones((50, 50)),
        dims=["y", "x"],
        affine=param_utils.affine_from_translation([3, 4]),
        transform_key="lo",
    )

    msim = msi_utils.get_msim_from_sims([sim_lo, sim_hi])

    assert msim["scale0/image"].shape[-2:] == (100, 100)
    assert msim["scale1/image"].shape[-2:] == (50, 50)
    assert "hi" in msim["scale0"].data_vars
    assert "hi" in msim["scale1"].data_vars
    assert "lo" not in msim["scale0"].data_vars
    assert "lo" not in msim["scale1"].data_vars
    assert np.allclose(msim["scale0"]["hi"], msim["scale1"]["hi"])


def test_get_msim_from_sims_requires_monotonic_shapes():
    # One dimension shrinks while another grows, so these cannot form one pyramid.
    sims = [
        si_utils.get_sim_from_array(np.ones(shape), dims=["y", "x"])
        for shape in [(100, 50), (80, 60)]
    ]

    with pytest.raises(ValueError, match="decrease monotonically"):
        msi_utils.get_msim_from_sims(sims)


def test_get_msim_from_sims_requires_matching_dims():
    sim = si_utils.get_sim_from_array(np.ones((10, 10)), dims=["y", "x"])

    # Dropping a non-spatial dimension should be rejected too.
    with pytest.raises(ValueError, match="same dimensions"):
        msi_utils.get_msim_from_sims([sim, sim.isel(c=0, drop=True)])


def test_msim_map_blocks_maps_every_scale_and_preserves_other_vars():
    sim = si_utils.get_sim_from_array(
        np.arange(64, dtype=np.float32).reshape(8, 8),
        dims=["y", "x"],
        affine=param_utils.affine_from_translation([1, 2]),
        transform_key="stage",
    )
    msim = msi_utils.get_msim_from_sim(
        sim,
        scale_factors=[{"y": 2, "x": 2}],
    )

    for iscale, scale_key in enumerate(msi_utils.get_sorted_scale_keys(msim)):
        msim[scale_key]["other_var"] = xr.DataArray(np.array(iscale))

    mapped = msi_utils.msim_map_blocks(msim, lambda block: block + 1)

    for scale_key in msi_utils.get_sorted_scale_keys(msim):
        expected = msim[f"{scale_key}/image"].data.compute() + 1
        actual = mapped[f"{scale_key}/image"].data.compute()

        np.testing.assert_array_equal(actual, expected)
        assert "stage" in mapped[scale_key].data_vars
        assert "other_var" in mapped[scale_key].data_vars
        assert mapped[scale_key]["other_var"].item() == msim[scale_key]["other_var"].item()


def test_msim_point_set_roundtrip_and_selection():
    sim = si_utils.get_sim_from_array(
        np.zeros((5, 5)),
        dims=["y", "x"],
    )
    points = np.array(
        [
            [1.0, 1.0],
            [2.0, 2.0],
            [4.0, 4.0],
        ]
    )
    si_utils.set_point_set(sim, points)

    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])

    assert "point_sets" in list(msim.keys())
    assert "beads" in list(msim["point_sets"].keys())
    assert "beads" not in msi_utils.get_transforms_from_dataset_as_dict(
        msim["scale0"]
    )
    assert msi_utils.get_point_set(msim)["position"].dims == (
        "t",
        "c",
        "point_id",
        "dim",
    )
    assert np.allclose(
        msi_utils.get_point_set(msim)["position"].isel(t=0, c=0),
        points,
    )

    sim_roundtrip = msi_utils.get_sim_from_msim(msim)
    assert si_utils.get_point_set(sim_roundtrip)["position"].dims == (
        "t",
        "c",
        "point_id",
        "dim",
    )
    assert np.allclose(
        si_utils.get_point_set(sim_roundtrip)["position"].isel(t=0, c=0),
        points,
    )

    selected = msi_utils.multiscale_sel_coords(msim, {"y": slice(0.0, 2.0)})
    assert msi_utils.get_point_set(selected)["position"].dims == (
        "t",
        "c",
        "point_id",
        "dim",
    )
    assert np.allclose(
        msi_utils.get_point_set(selected)["position"].isel(t=0, c=0).values,
        np.array([[1.0, 1.0], [2.0, 2.0]]),
    )


def test_concat_result_can_be_selected_with_multiscale_sel_coords():
    msims = [
        msi_utils.get_msim_from_sim(
            si_utils.get_sim_from_array(
                np.full((4, 5), value),
                dims=["y", "x"],
            ),
            scale_factors=[],
        )
        for value in range(2)
    ]

    selected = msi_utils.multiscale_sel_coords(
        msi_utils.concat(msims, dim="c"),
        {"y": slice(0.0, 1.0)},
    )

    sim = selected["scale0/image"]
    assert sim.dims == ("t", "c", "y", "x")
    assert sim.shape == (1, 2, 2, 5)
    np.testing.assert_array_equal(
        sim.isel(t=0, y=0, x=0).values,
        np.array([0, 1]),
    )


def test_concat_single_msim_short_circuits_without_materializing():
    """
    A single-item concat is a no-op; it must not fall through to the eager
    xr.concat path, which (unlike dask) doesn't keep zarr-backed sims lazy
    and would materialize the whole array for nothing.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        zarray = zarr.open_array(
            os.path.join(tmpdir, "input.zarr"),
            mode="w",
            shape=(1, 1, 8, 8),
            chunks=(1, 1, 8, 8),
            dtype=np.uint16,
        )
        zarray[:] = 7

        sim = si_utils.get_sim_from_array(
            zarray,
            dims=["t", "c", "y", "x"],
            scale={"y": 1.0, "x": 1.0},
            translation={"y": 0.0, "x": 0.0},
            t_coords=[0.0],
            c_coords=[0],
        )
        msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])

        combined = msi_utils.concat([msim], dim="c")

        assert combined is msim
        sim_out = msi_utils.get_sim_from_msim(combined)
        assert si_utils.is_xarray_zarr_backed(sim_out)
        np.testing.assert_array_equal(np.asarray(sim_out.data), zarray[:])
