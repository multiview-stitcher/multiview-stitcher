import os
import tempfile

import matplotlib
matplotlib.use("Agg")

import numpy as np
import pytest
import zarr
from matplotlib import pyplot as plt

import multiview_stitcher.spatial_image_utils as si_utils
from multiview_stitcher import (
    io,
    msi_utils,
    ngff_utils,
    param_utils,
    sample_data,
    vis_utils,
)
from multiview_stitcher.io import METADATA_TRANSFORM_KEY

@pytest.mark.parametrize(
    "ndim, N_t",
    [(2, 1), (2, 2), (3, 1), (3, 2)],
)
def test_plot_positions(ndim, N_t, monkeypatch):
    sims = sample_data.generate_tiled_dataset(
        ndim=ndim,
        N_c=2,
        N_t=N_t,
        tile_size=5,
        tiles_x=2,
        tiles_y=2,
        tiles_z=2,
    )

    msims = [
        msi_utils.get_msim_from_sim(sim, scale_factors=[]) for sim in sims
    ]

    monkeypatch.setattr(plt, "show", lambda: None)

    indexed_sims1 = set(sims[0].coords.xindexes.dims)

    fig, ax = vis_utils.plot_positions(
        sims, transform_key=METADATA_TRANSFORM_KEY
    )

    fig, ax = vis_utils.plot_positions(
        msims, transform_key=METADATA_TRANSFORM_KEY
    )

    assert len(ax.collections) == len(msims)

    indexed_sims2 = set(sims[0].coords.xindexes.dims)

    assert indexed_sims1 == indexed_sims2


def test_plot_positions_single_coord(monkeypatch):
    sim = si_utils.get_sim_from_array(
        np.random.randint(0, 255, (1, 100, 100)),
        dims=["z", "y", "x"],
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    vis_utils.plot_positions(
        [msi_utils.get_msim_from_sim(sim, scale_factors=[])],
        transform_key=si_utils.DEFAULT_TRANSFORM_KEY,
        use_positional_colors=False,
    )

    vis_utils.plot_positions(
        [msi_utils.get_msim_from_sim(sim, scale_factors=[])],
        transform_key=si_utils.DEFAULT_TRANSFORM_KEY,
        use_positional_colors=False,
        spacing={"x": 1, "y": 1, "z": 1},
    )


def test_plot_positions_point_sets(monkeypatch):
    affine = param_utils.affine_from_translation([10.0, 20.0])
    sim = si_utils.get_sim_from_array(
        np.zeros((10, 10)),
        dims=["y", "x"],
        affine=affine,
    )
    si_utils.set_point_set(
        sim,
        np.array([[1.0, 2.0], [3.0, 4.0]]),
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    point_positions = vis_utils._get_point_set_positions_for_plot(
        sim,
        points_key="beads",
        transform_key=si_utils.DEFAULT_TRANSFORM_KEY,
        sdims=["y", "x"],
    )
    assert np.allclose(
        point_positions,
        np.array([[0.0, 22.0, 11.0], [0.0, 24.0, 13.0]]),
    )

    fig, ax = vis_utils.plot_positions(
        [sim],
        transform_key=si_utils.DEFAULT_TRANSFORM_KEY,
        points_key="beads",
    )
    assert len(ax.collections) == 2
    plt.close(fig)


def test_imshow_msim_with_points(monkeypatch):
    data = np.arange(4 * 5 * 6, dtype=float).reshape(4, 5, 6)
    sim = si_utils.get_sim_from_array(
        data,
        dims=["z", "y", "x"],
        scale={"z": 2.0, "y": 3.0, "x": 4.0},
        translation={"z": 10.0, "y": 20.0, "x": 30.0},
    )
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])
    msi_utils.set_point_set(
        msim,
        np.array(
            [
                [10.0, 20.0, 30.0],
                [14.0, 23.0, 34.0],
                [16.0, 24.5, 34.0],
            ]
        ),
        points_key="beads",
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    fig, ax, sliders = vis_utils.imshow(
        msim,
        points_key="beads",
        points_tolerance=1,
        figure_kwargs={"figsize": (4, 3)},
        imshow_kwargs={"vmin": 0, "vmax": 100},
        scatter_kwargs={"s": 12, "edgecolor": "cyan"},
    )

    assert list(sliders.keys()) == ["z"]
    np.testing.assert_allclose(fig.get_size_inches(), np.array([4.0, 3.0]))
    assert ax.images[0].get_clim() == (0, 100)
    np.testing.assert_allclose(ax.collections[0].get_sizes(), np.array([12]))
    np.testing.assert_allclose(
        np.asarray(ax.images[0].get_extent(), dtype=float),
        np.array([28.0, 52.0, 33.5, 18.5]),
    )
    assert ax.get_xlabel() == "x"
    assert ax.get_ylabel() == "y"
    np.testing.assert_allclose(
        ax.collections[0].get_offsets(),
        np.array([[30.0, 20.0]]),
    )

    sliders["z"].set_val(2)
    np.testing.assert_allclose(
        ax.collections[0].get_offsets(),
        np.array([[34.0, 23.0], [34.0, 24.5]]),
    )
    plt.close(fig)


def test_imshow_without_points(monkeypatch):
    data = np.arange(4 * 5 * 6, dtype=float).reshape(4, 5, 6)
    sim = si_utils.get_sim_from_array(
        data,
        dims=["z", "y", "x"],
        scale={"z": 2.0, "y": 3.0, "x": 4.0},
        translation={"z": 10.0, "y": 20.0, "x": 30.0},
    )
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])
    msi_utils.set_point_set(
        msim,
        np.array(
            [
                [10.0, 20.0, 30.0],
                [14.0, 23.0, 34.0],
            ]
        ),
        points_key="beads",
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    fig, ax, sliders = vis_utils.imshow(
        msim,
        points_key=None,
    )

    assert list(sliders.keys()) == ["z"]
    assert len(ax.collections) == 0
    assert ax.get_xlabel() == "x"
    assert ax.get_ylabel() == "y"
    assert "points=" not in ax.get_title()
    plt.close(fig)


@pytest.mark.parametrize(
    "project_dim, expected_image, expected_offsets, expected_labels, expected_extent",
    [
        (
            "z",
            lambda data: data.max(axis=0),
            np.array([[30.0, 20.0], [34.0, 23.0], [34.0, 24.5]]),
            ("x", "y"),
            np.array([28.0, 52.0, 33.5, 18.5]),
        ),
        (
            "y",
            lambda data: data.max(axis=1),
            np.array([[30.0, 10.0], [34.0, 14.0], [34.0, 16.0]]),
            ("x", "z"),
            np.array([28.0, 52.0, 17.0, 9.0]),
        ),
        (
            "x",
            lambda data: data.max(axis=2).T,
            np.array([[10.0, 20.0], [14.0, 23.0], [16.0, 24.5]]),
            ("z", "y"),
            np.array([9.0, 17.0, 33.5, 18.5]),
        ),
    ],
)
def test_imshow_projection(
    monkeypatch,
    project_dim,
    expected_image,
    expected_offsets,
    expected_labels,
    expected_extent,
):
    data = np.arange(4 * 5 * 6, dtype=float).reshape(4, 5, 6)
    sim = si_utils.get_sim_from_array(
        data,
        dims=["z", "y", "x"],
        scale={"z": 2.0, "y": 3.0, "x": 4.0},
        translation={"z": 10.0, "y": 20.0, "x": 30.0},
    )
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])
    msi_utils.set_point_set(
        msim,
        np.array(
            [
                [10.0, 20.0, 30.0],
                [14.0, 23.0, 34.0],
                [16.0, 24.5, 34.0],
            ]
        ),
        points_key="beads",
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    fig, ax, sliders = vis_utils.imshow(
        msim,
        points_key="beads",
        project_dim=project_dim,
    )

    assert list(sliders.keys()) == []
    np.testing.assert_allclose(ax.images[0].get_array(), expected_image(data))
    np.testing.assert_allclose(ax.collections[0].get_offsets(), expected_offsets)
    np.testing.assert_allclose(
        np.asarray(ax.images[0].get_extent(), dtype=float),
        expected_extent,
    )
    assert ax.get_xlabel() == expected_labels[0]
    assert ax.get_ylabel() == expected_labels[1]
    assert f"project={project_dim}" in ax.get_title()
    plt.close(fig)


def test_imshow_points_key_and_resolution_behavior(monkeypatch):
    sim = si_utils.get_sim_from_array(
        np.zeros((5, 6)),
        dims=["y", "x"],
    )
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])

    monkeypatch.setattr(plt, "show", lambda: None)

    fig, ax, sliders = vis_utils.imshow(msim, points_key=None)
    assert list(sliders.keys()) == []
    assert len(ax.collections) == 0
    assert ax.get_xlabel() == "x"
    assert ax.get_ylabel() == "y"
    plt.close(fig)

    msi_utils.set_point_set(msim, np.array([[1.0, 2.0]]), points_key="beads")
    msi_utils.set_point_set(msim, np.array([[3.0, 4.0]]), points_key="spots")

    fig, ax, sliders = vis_utils.imshow(msim, points_key=None)
    assert list(sliders.keys()) == []
    assert len(ax.collections) == 0
    plt.close(fig)

    fig, ax, sliders = vis_utils.imshow(
        msim,
        points_key="beads",
    )
    assert list(sliders.keys()) == []
    assert ax.get_xlabel() == "x"
    assert ax.get_ylabel() == "y"
    plt.close(fig)

    with pytest.raises(ValueError, match="Point set 'missing' not found"):
        vis_utils.imshow(msim, points_key="missing")

    with pytest.raises(ValueError, match="horizontal_dim must be one of"):
        vis_utils.imshow(
            msim,
            points_key="beads",
            horizontal_dim="z",
        )

    with pytest.raises(ValueError, match="requires two displayed spatial dimensions"):
        vis_utils.imshow(
            msim,
            points_key="beads",
            project_dim="y",
        )

    with pytest.raises(ValueError, match="resolution_level is only supported"):
        vis_utils.imshow(sim, resolution_level=1)


def test_imshow_accepts_sim_and_custom_axes(monkeypatch):
    data = np.arange(4 * 5 * 6, dtype=float).reshape(4, 5, 6)
    sim = si_utils.get_sim_from_array(
        data,
        dims=["z", "y", "x"],
        scale={"z": 2.0, "y": 3.0, "x": 4.0},
        translation={"z": 10.0, "y": 20.0, "x": 30.0},
    )
    si_utils.set_point_set(
        sim,
        np.array(
            [
                [10.0, 20.0, 30.0],
                [14.0, 23.0, 34.0],
                [16.0, 24.5, 34.0],
            ]
        ),
        points_key="beads",
    )

    monkeypatch.setattr(plt, "show", lambda: None)

    fig, ax, sliders = vis_utils.imshow(
        sim,
        points_key="beads",
        points_tolerance=1,
        horizontal_dim="x",
        vertical_dim="y",
    )

    assert list(sliders.keys()) == ["z"]
    assert ax.get_xlabel() == "x"
    assert ax.get_ylabel() == "y"
    np.testing.assert_allclose(
        np.asarray(ax.images[0].get_extent(), dtype=float),
        np.array([28.0, 52.0, 33.5, 18.5]),
    )
    np.testing.assert_allclose(
        ax.collections[0].get_offsets(),
        np.array([[30.0, 20.0]]),
    )

    sliders["z"].set_val(2)
    np.testing.assert_allclose(
        ax.collections[0].get_offsets(),
        np.array([[34.0, 23.0], [34.0, 24.5]]),
    )
    plt.close(fig)


def test_neuroglancer_source_transform_matches_physical_affine():
    sdims = ["y", "x"]
    sim_spacing = {"y": 0.4, "x": 2.0}
    output_spacing = {"y": 1.2, "x": 0.5}
    origin = np.array([12.0, -6.0])
    pixel = np.array([5.0, 8.0])

    theta = np.deg2rad(30)
    linear = np.array(
        [
            [np.cos(theta), -np.sin(theta)],
            [np.sin(theta), np.cos(theta)],
        ]
    )
    translation = np.array([3.5, -7.0])
    affine = np.eye(3)
    affine[:2, :2] = linear
    affine[:2, 2] = translation

    ng_affine = vis_utils._affine_to_neuroglancer_source_transform(
        affine,
        sdims=sdims,
        output_spacing=output_spacing,
    )

    sim_spacing_array = np.array([sim_spacing[dim] for dim in sdims])
    output_spacing_array = np.array([output_spacing[dim] for dim in sdims])

    expected_world = linear @ (sim_spacing_array * pixel + origin)
    expected_world += translation

    source_coords = pixel + origin / sim_spacing_array
    ng_linear = (
        ng_affine[:2, :2]
        * sim_spacing_array[None, :]
        / output_spacing_array[:, None]
    )
    ng_output_coords = ng_linear @ source_coords + ng_affine[:2, 2]
    neuroglancer_world = output_spacing_array * ng_output_coords

    np.testing.assert_allclose(neuroglancer_world, expected_world)
    np.testing.assert_allclose(
        ng_affine[:2, 2], translation / output_spacing_array
    )


def test_view_neuroglancer_corrects_spacing_origin_mismatch():
    """
    When in-memory sims have different spacing/origin than the on-disk OME-Zarr,
    generate_neuroglancer_json must include a correction so that the
    pixel → world mapping is consistent with applying the registered affine
    in in-memory physical coordinates.
    """
    sdims = ["y", "x"]
    ndim = len(sdims)

    # On-disk OME-Zarr spacing/origin
    spacing_zarr = {"y": 0.5, "x": 0.5}
    origin_zarr = {"y": 0.0, "x": 0.0}

    # In-memory sim: user changed spacing and origin
    spacing_mem = {"y": 1.0, "x": 2.0}
    origin_mem = {"y": 10.0, "x": -5.0}

    # Registered affine expressed in in-memory physical coordinates
    theta = np.deg2rad(15)
    linear = np.array(
        [
            [np.cos(theta), -np.sin(theta)],
            [np.sin(theta), np.cos(theta)],
        ]
    )
    translation = np.array([3.0, -2.0])
    mem_affine = np.eye(ndim + 1)
    mem_affine[:ndim, :ndim] = linear
    mem_affine[:ndim, ndim] = translation

    # Compute the correction that maps zarr physical coords → mem physical coords
    correction = np.eye(ndim + 1)
    for i, dim in enumerate(sdims):
        scale = spacing_mem[dim] / spacing_zarr[dim]
        correction[i, i] = scale
        correction[i, ndim] = origin_mem[dim] - origin_zarr[dim] * scale

    composed_affine = mem_affine @ correction

    ng_affine = vis_utils._affine_to_neuroglancer_source_transform(
        composed_affine,
        sdims=sdims,
        output_spacing=spacing_zarr,
    )

    # Verify for a test pixel that neuroglancer produces the expected world coordinate
    pixel = np.array([3.0, 7.0])

    # Expected world: apply mem_affine to the in-memory physical coordinate of the pixel
    mem_phys = np.array(
        [pixel[i] * spacing_mem[sdims[i]] + origin_mem[sdims[i]] for i in range(ndim)]
    )
    expected_world = linear @ mem_phys + translation

    # Neuroglancer's internal computation (mirrors the formula in
    # test_neuroglancer_source_transform_matches_physical_affine)
    zarr_spacing_arr = np.array([spacing_zarr[dim] for dim in sdims])
    zarr_origin_arr = np.array([origin_zarr[dim] for dim in sdims])
    output_spacing_arr = zarr_spacing_arr  # outputDimensions uses zarr spacing

    source_coords = pixel + zarr_origin_arr / zarr_spacing_arr
    ng_linear = (
        ng_affine[:ndim, :ndim]
        * zarr_spacing_arr[None, :]
        / output_spacing_arr[:, None]
    )
    ng_output_coords = ng_linear @ source_coords + ng_affine[:ndim, ndim]
    neuroglancer_world = output_spacing_arr * ng_output_coords

    np.testing.assert_allclose(neuroglancer_world, expected_world, rtol=1e-10)


def test_view_neuroglancer_spacing_origin_mismatch_integration():
    """
    Integration test: generate_neuroglancer_json produces correct source-transform
    matrices when in-memory sims have spacing/origin different from on-disk OME-Zarr.
    """
    import dask.array as da
    import xarray as xr

    sdims = ["y", "x"]
    ndim = len(sdims)
    tile_size = 10

    spacing_zarr = {"y": 0.5, "x": 0.5}
    origin_zarr = {"y": 0.0, "x": 0.0}
    spacing_mem = {"y": 1.0, "x": 2.0}
    origin_mem = {"y": 10.0, "x": -5.0}

    theta = np.deg2rad(15)
    linear = np.array(
        [
            [np.cos(theta), -np.sin(theta)],
            [np.sin(theta), np.cos(theta)],
        ]
    )
    translation = np.array([3.0, -2.0])
    mem_affine_np = np.eye(ndim + 1)
    mem_affine_np[:ndim, :ndim] = linear
    mem_affine_np[:ndim, ndim] = translation
    xaffine = param_utils.affine_to_xaffine(mem_affine_np)

    # Build zarr-backed sim (use dask array so write_sim_to_ome_zarr works)
    sim_zarr = xr.DataArray(
        da.zeros((tile_size, tile_size), chunks=(tile_size, tile_size)),
        dims=sdims,
        coords={
            dim: np.arange(tile_size) * spacing_zarr[dim] + origin_zarr[dim]
            for dim in sdims
        },
    )
    si_utils.set_sim_affine(sim_zarr, xaffine, transform_key="test")

    # Build in-memory sim with different spacing/origin but same registered affine
    sim_mem = xr.DataArray(
        np.zeros((tile_size, tile_size)),
        dims=sdims,
        coords={
            dim: np.arange(tile_size) * spacing_mem[dim] + origin_mem[dim]
            for dim in sdims
        },
    )
    si_utils.set_sim_affine(sim_mem, xaffine, transform_key="test")

    with tempfile.TemporaryDirectory() as data_dir:
        zarr_path = os.path.join(data_dir, "sim.zarr")
        ngff_utils.write_sim_to_ome_zarr(sim_zarr, zarr_path)

        ng_json = vis_utils.generate_neuroglancer_json(
            ome_zarr_paths=[zarr_path],
            ome_zarr_urls=["http://localhost:8000/sim.zarr"],
            sims=[sim_mem],
            transform_key="test",
        )

        # Extract source-transform matrix and output spacing from JSON
        source_transform = ng_json["layers"][0]["source"]["transform"]
        matrix = np.array(source_transform["matrix"])  # shape (len(dims), len(dims)+1)
        output_dims = source_transform["outputDimensions"]
        output_spacing_arr = np.array(
            [output_dims[dim][0] / 1e-6 for dim in sdims]
        )
        assert all(output_dims[dim][1] == "m" for dim in sdims)

        # The spatial block lives in the last ndim rows and last ndim+1 cols
        # (linear part in [-ndim:, -ndim-1:-1], translation in [-ndim:, -1])
        ng_linear_block = matrix[-ndim:, -ndim - 1 : -1]
        ng_translation = matrix[-ndim:, -1]

        # Verify pixel → world coordinate
        pixel = np.array([3.0, 7.0])

        mem_phys = np.array(
            [
                pixel[i] * spacing_mem[sdims[i]] + origin_mem[sdims[i]]
                for i in range(ndim)
            ]
        )
        expected_world = linear @ mem_phys + translation

        zarr_spacing_arr = np.array([spacing_zarr[dim] for dim in sdims])
        zarr_origin_arr = np.array([origin_zarr[dim] for dim in sdims])

        ng_linear_scaled = (
            ng_linear_block
            * zarr_spacing_arr[None, :]
            / output_spacing_arr[:, None]
        )
        source_coords = pixel + zarr_origin_arr / zarr_spacing_arr
        ng_output_coords = ng_linear_scaled @ source_coords + ng_translation
        neuroglancer_world = output_spacing_arr * ng_output_coords

        np.testing.assert_allclose(neuroglancer_world, expected_world, rtol=1e-5)


@pytest.mark.parametrize(
    "ndim, N_t, N_c, option",
    [
        (2, 1, 1, ""),
        (2, 2, 1, ""),
        (3, 1, 2, ""),
        (2, None, None, ""),
        (2, None, 1, "different_c_coords"),
    ],
)
def test_ome_zarr_ng(ndim, N_t, N_c, option):
    sims = sample_data.generate_tiled_dataset(
        ndim=ndim,
        overlap=0,
        N_c=N_c if N_c is not None else 1,
        N_t=N_t if N_t is not None else 1,
        tile_size=10,
        tiles_x=2,
        tiles_y=1,
        tiles_z=1,
        spacing_x=0.1,
        spacing_y=0.1,
        spacing_z=2,
    )

    # make sure to also test for the absence of c and t
    if N_c is None:
        for isim in range(len(sims)):
            sims[isim] = sims[isim].drop_vars("c")

    if N_t is None:
        for isim in range(len(sims)):
            sims[isim] = sims[isim].drop_vars("t")

    # test case of different
    if option == "different_c_coords":
        for isim in range(len(sims)):
            sims[isim] = sims[isim].assign_coords(c=[f"channel {isim}"])

    with tempfile.TemporaryDirectory() as data_dir:
        zarr_paths = [
            os.path.join(data_dir, f"sim_{isim}.zarr")
            for isim in range(len(sims))
        ]
        [
            ngff_utils.write_sim_to_ome_zarr(sim, zarr_paths[isim])
            for isim, sim in enumerate(sims)
        ]

        for single_layer in [True, False]:
            ng_json = vis_utils.generate_neuroglancer_json(
                ome_zarr_paths=zarr_paths,
                ome_zarr_urls=[
                    f"https://localhost:8000/{os.path.basename(zp)}"
                    for zp in zarr_paths
                ],
                sims=sims,
                transform_key=io.METADATA_TRANSFORM_KEY,
                single_layer=single_layer,
            )
            assert len(ng_json.keys())
            assert ng_json["dimensions"]["y"] == [0.1e-6, "m"]
            assert ng_json["dimensions"]["x"] == [0.1e-6, "m"]
            if "z" in sims[0].dims:
                assert ng_json["dimensions"]["z"] == [2e-6, "m"]
            if "t" in sims[0].dims:
                assert ng_json["dimensions"]["t"] == [1.0, ""]
            if "c" in sims[0].dims:
                assert ng_json["dimensions"]["c"] == [1.0, ""]
            assert "np.float" not in str(ng_json)
            matrix = (
                ng_json["layers"][0]["source"][0]["transform"]["matrix"]
                if single_layer
                else ng_json["layers"][0]["source"]["transform"]["matrix"]
            )
            output_dims = (
                ng_json["layers"][0]["source"][0]["transform"][
                    "outputDimensions"
                ]
                if single_layer
                else ng_json["layers"][0]["source"]["transform"][
                    "outputDimensions"
                ]
            )
            expected_source_dims = list(sims[0].dims)
            expected_output_dims = [
                dim if dim != "c" else "c'"
                for dim in expected_source_dims
            ]
            assert list(output_dims) == expected_output_dims
            assert np.asarray(matrix).shape == (
                len(expected_source_dims),
                len(expected_source_dims) + 1,
            )
            assert list(ng_json["dimensions"]) == expected_source_dims
            assert output_dims["y"] == [0.1e-6, "m"]
            assert output_dims["x"] == [0.1e-6, "m"]
            if "z" in sims[0].dims:
                assert output_dims["z"] == [2e-6, "m"]
            if "c" not in sims[0].dims:
                assert "c'" not in output_dims
            if "t" not in sims[0].dims:
                assert "t" not in output_dims
            assert type(matrix[0][0]) is float

        # test with channel coord
        if option != "different_c_coords":
            ng_json = vis_utils.generate_neuroglancer_json(
                ome_zarr_paths=zarr_paths,
                ome_zarr_urls=[
                    f"https://localhost:8000/{os.path.basename(zp)}"
                    for zp in zarr_paths
                ],
                sims=sims,
                channel_coord=sims[0].coords["c"].values[0],
                transform_key=io.METADATA_TRANSFORM_KEY,
                single_layer=single_layer,
            )
            assert len(ng_json.keys())

        # without sims
        ng_json = vis_utils.generate_neuroglancer_json(
            ome_zarr_paths=zarr_paths,
            ome_zarr_urls=[
                f"https://localhost:8000/{os.path.basename(zp)}"
                for zp in zarr_paths
            ],
        )
        assert len(ng_json.keys())


def test_generate_neuroglancer_json_xy_layout_for_3d():
    sim = sample_data.generate_tiled_dataset(
        ndim=3,
        overlap=0,
        N_c=1,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]

    default_config = vis_utils.generate_neuroglancer_json(
        ome_zarr_paths=None,
        ome_zarr_urls=["http://example.invalid/image"],
        sims=[sim],
    )
    xy_config = vis_utils.generate_neuroglancer_json(
        ome_zarr_paths=None,
        ome_zarr_urls=["http://example.invalid/image"],
        sims=[sim],
        layout="xy",
    )

    assert default_config["layout"] == "4panel"
    assert xy_config["layout"] == "xy"


def test_get_neuroglancer_url_custom_base():
    ng_json = {"layout": "xy"}

    default_url = vis_utils.get_neuroglancer_url(ng_json)
    assert default_url.startswith(
        vis_utils._DEFAULT_NEUROGLANCER_URL + "/#!"
    )

    custom_url = vis_utils.get_neuroglancer_url(
        ng_json, neuroglancer_url="https://ng.example.org/viewer/"
    )
    assert custom_url.startswith("https://ng.example.org/viewer/#!")
    # the encoded state is identical regardless of the base URL
    assert default_url.split("#!")[1] == custom_url.split("#!")[1]


def test_view_neuroglancer_images_param(monkeypatch):
    """
    view_neuroglancer accepts `images=` with sims and msims, and emits a
    DeprecationWarning when the legacy `sims=` parameter is used.
    """
    import warnings
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)
    monkeypatch.setattr(vis_utils, "serve_dir", lambda *a, **kw: None)

    sims = sample_data.generate_tiled_dataset(
        ndim=2, overlap=0, N_c=1, N_t=1, tile_size=10, tiles_x=2, tiles_y=1, tiles_z=1
    )
    msims = [msi_utils.get_msim_from_sim(sim, scale_factors=[]) for sim in sims]

    with tempfile.TemporaryDirectory() as data_dir:
        zarr_paths = [
            os.path.join(data_dir, f"sim_{i}.zarr") for i in range(len(sims))
        ]
        for sim, zp in zip(sims, zarr_paths):
            ngff_utils.write_sim_to_ome_zarr(sim, zp)

        # images= accepts plain sims
        vis_utils.view_neuroglancer(
            zarr_paths, images=sims, transform_key=io.METADATA_TRANSFORM_KEY
        )

        # images= accepts msims (DataTree)
        vis_utils.view_neuroglancer(
            zarr_paths, images=msims, transform_key=io.METADATA_TRANSFORM_KEY
        )

        # legacy sims= triggers a DeprecationWarning
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            vis_utils.view_neuroglancer(
                zarr_paths, sims=sims, transform_key=io.METADATA_TRANSFORM_KEY
            )
        assert any(issubclass(w.category, DeprecationWarning) for w in caught)


def test_view_neuroglancer_virtual_images(monkeypatch):
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)

    served = []
    captured_json = []
    captured_ng_url_kwargs = []

    class FakeVirtualServer:
        urls = ["http://127.0.0.1:8123/image_0"]

        def serve_forever(self):
            served.append(True)

    def fake_serve_virtual_ome_zarrs(msims, **kwargs):
        assert len(msims) == 1
        assert kwargs["port"] == 8123
        return FakeVirtualServer()

    def capture_ng_url(ng_json, **kwargs):
        captured_json.append(ng_json)
        captured_ng_url_kwargs.append(kwargs)
        return "https://example.invalid/neuroglancer"

    monkeypatch.setattr(
        ngff_utils,
        "serve_virtual_ome_zarrs",
        fake_serve_virtual_ome_zarrs,
    )
    monkeypatch.setattr(vis_utils, "get_neuroglancer_url", capture_ng_url)

    sim = sample_data.generate_tiled_dataset(
        ndim=3,
        overlap=0,
        N_c=1,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])

    vis_utils.view_neuroglancer(
        images=[msim],
        transform_key=io.METADATA_TRANSFORM_KEY,
        port=8123,
        layout="xy",
        neuroglancer_url="https://ng.example.org",
    )

    assert served == [True]
    assert captured_json
    assert captured_json[0]["layout"] == "xy"
    assert captured_ng_url_kwargs[0]["neuroglancer_url"] == (
        "https://ng.example.org"
    )
    source = captured_json[0]["layers"][0]["source"]
    assert source["url"] == "http://127.0.0.1:8123/image_0"
    assert "transform" in source
    assert captured_json[0]["dimensions"]["t"] == [1, ""]
    assert captured_json[0]["dimensions"]["c"] == [1, ""]
    assert captured_json[0]["dimensions"]["y"] == [0.5, "um"]
    assert captured_json[0]["dimensions"]["x"] == [0.5, "um"]
    assert source["transform"]["outputDimensions"]["t"] == [1, ""]
    assert source["transform"]["outputDimensions"]["c'"] == [1, ""]
    assert source["transform"]["outputDimensions"]["y"] == [0.5, "um"]
    assert source["transform"]["outputDimensions"]["x"] == [0.5, "um"]


def test_view_neuroglancer_virtual_display_metadata(monkeypatch):
    """Multichannel colormaps are exposed without mutating msims."""
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)

    captured_omero_channels = []

    class FakeVirtualServer:
        urls = [
            "http://127.0.0.1:8123/image_0",
            "http://127.0.0.1:8123/image_1",
        ]

        def serve_forever(self):
            pass

    def fake_serve_virtual_ome_zarrs(msims, **kwargs):
        captured_omero_channels.extend(kwargs["omero_channels"])
        return FakeVirtualServer()

    monkeypatch.setattr(
        ngff_utils,
        "serve_virtual_ome_zarrs",
        fake_serve_virtual_ome_zarrs,
    )
    monkeypatch.setattr(
        vis_utils,
        "get_neuroglancer_url",
        lambda ng_json, **kwargs: "https://example.invalid/neuroglancer",
    )

    sims = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=2,
        N_t=1,
        tile_size=10,
        tiles_x=2,
        tiles_y=1,
        tiles_z=1,
    )
    msims = [
        msi_utils.get_msim_from_sim(sim, scale_factors=[]) for sim in sims
    ]
    old_omero = {
        "channels": [
            {
                "color": "ffffff",
                "label": "existing",
                "active": True,
                "window": {"min": 0, "max": 10, "start": 1, "end": 9},
            }
        ]
    }
    msims[0].attrs["omero"] = old_omero

    vis_utils.view_neuroglancer(
        images=msims,
        colormaps=["Reds", "Greens"],
        contrast_limits=[(2, 20), (3, 30)],
        port=8123,
    )

    assert [
        omero["channels"][0]["color"]
        for omero in captured_omero_channels
    ] == [
        vis_utils._colormap_to_omero_color("Reds"),
        vis_utils._colormap_to_omero_color("Reds"),
    ]
    assert [
        omero["channels"][1]["color"]
        for omero in captured_omero_channels
    ] == [
        vis_utils._colormap_to_omero_color("Greens"),
        vis_utils._colormap_to_omero_color("Greens"),
    ]
    assert captured_omero_channels[0]["channels"][0]["label"] == "existing"
    assert captured_omero_channels[0]["channels"][0]["window"] == {
        "min": 2,
        "max": 20,
        "start": 2,
        "end": 20,
    }
    assert captured_omero_channels[0]["channels"][1]["window"] == {
        "min": 3,
        "max": 30,
        "start": 3,
        "end": 30,
    }
    channel = captured_omero_channels[0]["channels"][0]
    assert channel["color"] == channel["color"].upper()
    assert channel["coefficient"] == 1
    assert channel["family"] == "linear"
    assert channel["inverted"] is False
    assert captured_omero_channels[1]["channels"][0]["window"]["end"] == 20
    assert captured_omero_channels[1]["channels"][1]["window"]["end"] == 30
    assert msims[0].attrs["omero"] == old_omero


def test_view_neuroglancer_use_positional_colors(monkeypatch):
    """use_positional_colors assigns different colors to overlapping tiles."""
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)

    captured_omero_channels = []

    class FakeVirtualServer:
        urls = [
            "http://127.0.0.1:8127/image_0",
            "http://127.0.0.1:8127/image_1",
        ]

        def serve_forever(self):
            pass

    def fake_serve_virtual_ome_zarrs(msims, **kwargs):
        captured_omero_channels.extend(kwargs["omero_channels"])
        return FakeVirtualServer()

    monkeypatch.setattr(
        ngff_utils,
        "serve_virtual_ome_zarrs",
        fake_serve_virtual_ome_zarrs,
    )
    monkeypatch.setattr(
        vis_utils,
        "get_neuroglancer_url",
        lambda ng_json, **kwargs: "https://example.invalid/neuroglancer",
    )

    sims = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0.2,
        N_c=1,
        N_t=1,
        tile_size=10,
        tiles_x=2,
        tiles_y=1,
        tiles_z=1,
    )
    msims = [
        msi_utils.get_msim_from_sim(sim, scale_factors=[]) for sim in sims
    ]

    vis_utils.view_neuroglancer(
        images=msims,
        transform_key=METADATA_TRANSFORM_KEY,
        use_positional_colors=True,
        port=8127,
    )

    from matplotlib import colors as mpl_colors

    result_colors = [
        omero["channels"][0]["color"] for omero in captured_omero_channels
    ]
    # overlapping tiles must be assigned different colors
    assert result_colors[0] != result_colors[1]
    expected_hex_colors = {
        mpl_colors.to_hex(name, keep_alpha=False)[1:].upper()
        for name in vis_utils._POSITIONAL_COLOR_PALETTE
    }
    assert set(result_colors) <= expected_hex_colors


def test_view_neuroglancer_use_positional_colors_validation():
    sims = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0.2,
        N_c=2,
        N_t=1,
        tile_size=10,
        tiles_x=2,
        tiles_y=1,
        tiles_z=1,
    )
    msims = [
        msi_utils.get_msim_from_sim(sim, scale_factors=[]) for sim in sims
    ]

    # mutually exclusive with colormaps
    with pytest.raises(ValueError, match="mutually exclusive"):
        vis_utils.view_neuroglancer(
            images=msims,
            use_positional_colors=True,
            colormaps=["Reds", "Greens"],
        )

    # requires images/sims to compute tile positions
    with pytest.raises(ValueError, match="requires 'images' or 'sims'"):
        vis_utils.view_neuroglancer(
            ome_zarr_paths=["unused.zarr"],
            use_positional_colors=True,
        )

    # only supported for single-channel images
    with pytest.raises(ValueError, match="single-channel"):
        vis_utils.view_neuroglancer(
            images=msims,
            transform_key=METADATA_TRANSFORM_KEY,
            use_positional_colors=True,
        )


def test_view_neuroglancer_channel_coord_serves_selected_channel(monkeypatch):
    """channel_coord slices every scale and forces virtual OME-Zarr serving."""
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)
    monkeypatch.setattr(
        vis_utils,
        "get_neuroglancer_url",
        lambda ng_json, **kwargs: "https://example.invalid/neuroglancer",
    )
    monkeypatch.setattr(
        vis_utils,
        "serve_dir",
        lambda *args, **kwargs: pytest.fail("serve_dir must not be used"),
    )

    captured_msims = []
    captured_omero_channels = []

    class FakeVirtualServer:
        urls = ["http://127.0.0.1:8126/image_0"]

        def serve_forever(self):
            pass

    def fake_serve_virtual_ome_zarrs(msims, **kwargs):
        captured_msims.extend(msims)
        captured_omero_channels.extend(kwargs["omero_channels"])
        return FakeVirtualServer()

    monkeypatch.setattr(
        ngff_utils,
        "serve_virtual_ome_zarrs",
        fake_serve_virtual_ome_zarrs,
    )

    sim = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=2,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]
    msim = msi_utils.get_msim_from_sim(sim, scale_factors=[])
    selected_channel = sim.coords["c"].values[1]

    vis_utils.view_neuroglancer(
        ome_zarr_paths=["unused-because-selection-is-virtual.zarr"],
        images=[msim],
        channel_coord=selected_channel,
        colormaps=["Greens"],
        port=8126,
    )

    served_sim = msi_utils.get_sim_from_msim(captured_msims[0])
    assert served_sim.sizes["c"] == 1
    assert str(served_sim.coords["c"].item()) == str(selected_channel)
    assert sim.sizes["c"] == 2
    assert captured_omero_channels[0]["channels"][0]["label"] == str(
        selected_channel
    )

    with tempfile.TemporaryDirectory() as data_dir:
        zarr_path = os.path.join(data_dir, "multichannel.zarr")
        ngff_utils.write_sim_to_ome_zarr(sim, zarr_path)
        vis_utils.view_neuroglancer(
            ome_zarr_paths=[zarr_path],
            channel_coord=selected_channel,
            colormaps=["Greens"],
            port=8126,
        )

    path_served_sim = msi_utils.get_sim_from_msim(captured_msims[1])
    assert path_served_sim.sizes["c"] == 1
    assert str(path_served_sim.coords["c"].item()) == str(selected_channel)


def test_view_neuroglancer_virtual_images_without_transform(monkeypatch):
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)

    served = []
    captured_json = []

    class FakeVirtualServer:
        urls = ["http://127.0.0.1:8124/image_0"]

        def serve_forever(self):
            served.append(True)

    monkeypatch.setattr(
        ngff_utils,
        "serve_virtual_ome_zarrs",
        lambda msims, **kwargs: FakeVirtualServer(),
    )
    monkeypatch.setattr(
        vis_utils,
        "get_neuroglancer_url",
        lambda ng_json, **kwargs: captured_json.append(ng_json)
        or "https://example.invalid/neuroglancer",
    )

    sim = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=1,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]

    vis_utils.view_neuroglancer(images=[sim], port=8124)

    assert served == [True]
    assert captured_json
    source = captured_json[0]["layers"][0]["source"]
    assert source["url"] == "http://127.0.0.1:8124/image_0"
    assert source["transform"] == {}
    assert captured_json[0]["dimensions"]["t"] == [1, ""]
    assert captured_json[0]["dimensions"]["c"] == [1, ""]
    assert captured_json[0]["dimensions"]["y"] == [0.5, "um"]
    assert captured_json[0]["dimensions"]["x"] == [0.5, "um"]


def test_view_neuroglancer_local_display_metadata_is_restored(monkeypatch):
    """On-disk OMERO metadata exists only while the directory is served."""
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)
    monkeypatch.setattr(
        vis_utils,
        "get_neuroglancer_url",
        lambda ng_json, **kwargs: "https://example.invalid/neuroglancer",
    )

    sim = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=2,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]

    with tempfile.TemporaryDirectory() as data_dir:
        zarr_path = os.path.join(data_dir, "sim.zarr")
        ngff_utils.write_sim_to_ome_zarr(sim, zarr_path)
        original_omero = zarr.open_group(zarr_path, mode="r").attrs["omero"]
        served_omero = []

        def fake_serve_dir(dir_path, port=8000):
            served_omero.append(
                zarr.open_group(zarr_path, mode="r").attrs["omero"]
            )

        monkeypatch.setattr(vis_utils, "serve_dir", fake_serve_dir)

        # A single pair retains backward-compatible broadcast semantics.
        vis_utils.view_neuroglancer(
            [zarr_path],
            colormaps=["Blues", "Reds"],
            contrast_limits=(4, 40),
            port=8125,
        )

        restored_omero = zarr.open_group(zarr_path, mode="r").attrs["omero"]

    channel = served_omero[0]["channels"][0]
    assert channel["color"] == vis_utils._colormap_to_omero_color("Blues")
    assert channel["window"] == {
        "min": 4,
        "max": 40,
        "start": 4,
        "end": 40,
    }
    assert served_omero[0]["channels"][1]["window"] == channel["window"]
    assert restored_omero == original_omero


def test_view_neuroglancer_display_setting_validation():
    with pytest.raises(ValueError, match="number of image sources"):
        vis_utils._normalize_display_settings(["Reds"], None, [1, 1])

    with pytest.raises(ValueError, match="min < max"):
        vis_utils._normalize_display_settings(None, (10, 1), [1, 1])

    single_channel_colormaps, _ = vis_utils._normalize_display_settings(
        ["Reds", "Greens"], None, [1, 1]
    )
    assert single_channel_colormaps == [["Reds"], ["Greens"]]

    multichannel_colormaps, _ = vis_utils._normalize_display_settings(
        ["Reds", "Greens"], None, [2, 2]
    )
    assert multichannel_colormaps == [
        ["Reds", "Greens"],
        ["Reds", "Greens"],
    ]

    sim = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=2,
        N_t=1,
        tile_size=10,
        tiles_x=1,
        tiles_y=1,
        tiles_z=1,
    )[0]
    with pytest.raises(ValueError, match="one .* pair per channel"):
        vis_utils._temporary_omero_metadata(
            None, contrast_limits=[(0, 10)], sim=sim
        )


def test_view_neuroglancer_different_folders(monkeypatch):
    """
    view_neuroglancer must:
    - serve from the common root when zarrs are in different sub-directories
    - use forward slashes in URLs (cross-platform)
    - emit a UserWarning and skip serving when the depth exceeds the max
    """
    import warnings
    import webbrowser

    monkeypatch.setattr(webbrowser, "open", lambda url: None)

    sims = sample_data.generate_tiled_dataset(
        ndim=2,
        overlap=0,
        N_c=1,
        N_t=1,
        tile_size=10,
        tiles_x=2,
        tiles_y=1,
        tiles_z=1,
    )

    with tempfile.TemporaryDirectory() as root_dir:
        # place the two zarrs in different sub-directories
        zarr_paths = []
        for isim, sim in enumerate(sims):
            sub_dir = os.path.join(root_dir, f"subdir_{isim}")
            os.makedirs(sub_dir, exist_ok=True)
            zp = os.path.join(sub_dir, f"sim_{isim}.zarr")
            ngff_utils.write_sim_to_ome_zarr(sim, zp)
            zarr_paths.append(zp)

        served_dirs = []
        monkeypatch.setattr(
            vis_utils, "serve_dir", lambda d, port=8000: served_dirs.append(d)
        )

        generated_urls = []
        original_generate = vis_utils.generate_neuroglancer_json

        def capture_urls(ome_zarr_paths, ome_zarr_urls, **kwargs):
            generated_urls.extend(ome_zarr_urls)
            return original_generate(
                ome_zarr_paths=ome_zarr_paths,
                ome_zarr_urls=ome_zarr_urls,
                **kwargs,
            )

        monkeypatch.setattr(vis_utils, "generate_neuroglancer_json", capture_urls)

        vis_utils.view_neuroglancer(zarr_paths, port=8000)

        common_root = os.path.commonpath(
            [os.path.dirname(os.path.abspath(p)) for p in zarr_paths]
        )

        # server started at the common root
        assert len(served_dirs) == 1
        assert os.path.abspath(served_dirs[0]) == os.path.abspath(common_root)

        # URLs use forward slashes and correct relative paths
        for path, url in zip(zarr_paths, generated_urls):
            rel = os.path.relpath(os.path.abspath(path), common_root).replace(
                os.sep, "/"
            )
            assert url == f"http://localhost:8000/{rel}"
            assert "\\" not in url

    # depth > max: should warn and not serve
    # Use two zarrs whose common ancestor is more than _MAX_SERVE_DEPTH
    # levels above each zarr (e.g. root/a/b/c/d/ and root/e/f/g/h/ -> common=root, depth=5)
    _MAX_SERVE_DEPTH = 3
    with tempfile.TemporaryDirectory() as root_dir:
        deep_zarr_paths = []
        for branch in ["a/b/c/d", "e/f/g/h"]:
            deep_sub = os.path.join(root_dir, *branch.split("/"))
            os.makedirs(deep_sub, exist_ok=True)
            zp = os.path.join(deep_sub, f"sim_{branch.replace('/', '_')}.zarr")
            ngff_utils.write_sim_to_ome_zarr(sims[0], zp)
            deep_zarr_paths.append(zp)

        served_dirs.clear()
        generated_urls.clear()

        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            vis_utils.view_neuroglancer(deep_zarr_paths, port=8000)

        assert any(issubclass(w.category, UserWarning) for w in caught)
        # serve_dir must NOT have been called
        assert len(served_dirs) == 0


def _write_time_scaled_ome_zarr(zarr_path, t_scale, t_unit, n_t=4):
    """An OME-Zarr whose time axis is calibrated in real units.

    The calibration is patched in afterwards because a sim built from scratch
    carries none, and it is the store - not the sim - that a viewer reads.
    """
    sim = si_utils.get_sim_from_array(
        np.zeros((n_t, 1, 8, 8), dtype=np.uint16),
        dims=["t", "c", "y", "x"],
        scale={"y": 0.5, "x": 0.5},
        transform_key=METADATA_TRANSFORM_KEY,
    )
    ngff_utils.write_sim_to_ome_zarr(sim, zarr_path)

    root = zarr.open_group(zarr_path, mode="a")
    attrs = dict(root.attrs)
    multiscales = attrs["multiscales"][0]
    t_index = [axis["name"] for axis in multiscales["axes"]].index("t")
    multiscales["axes"][t_index]["unit"] = t_unit
    for dataset in multiscales["datasets"]:
        for transform in dataset["coordinateTransformations"]:
            if transform["type"] == "scale":
                transform["scale"][t_index] = t_scale
    attrs["multiscales"] = [multiscales]
    root.attrs.update(attrs)

    return zarr_path


@pytest.mark.parametrize(
    "t_scale, t_unit, expected",
    [
        (5.0, "second", [5.0, "s"]),
        (100.0, "millisecond", [0.1, "s"]),
        (2.0, None, [2.0, ""]),
        (1.0, "second", [1.0, "s"]),
    ],
)
def test_neuroglancer_state_declares_the_stores_time_scale(
    t_scale, t_unit, expected
):
    """The time dimension must describe the store the viewer actually reads.

    Neuroglancer scales every layer by the ratio between the time scale the
    store declares and the one named in the state.  Naming 1 for a store
    calibrated in seconds stretches the layer along `t` by that scale, so a
    position expressed in frames - which is what the app's time slider sets -
    lands on a different frame than the one asked for.
    """
    with tempfile.TemporaryDirectory() as tmp_dir:
        zarr_path = _write_time_scaled_ome_zarr(
            os.path.join(tmp_dir, "scaled.ome.zarr"), t_scale, t_unit
        )
        msim = ngff_utils.read_msim_from_ome_zarr(
            zarr_path, transform_key=METADATA_TRANSFORM_KEY
        )
        sim = msi_utils.get_sim_from_msim(msim)

        ng_json = vis_utils.generate_neuroglancer_json(
            ome_zarr_paths=None,
            ome_zarr_urls=["zarr://http://localhost:8000/scaled.ome.zarr"],
            sims=[sim],
            transform_key=METADATA_TRANSFORM_KEY,
        )

        assert ng_json["dimensions"]["t"] == expected
        source_transform = ng_json["layers"][0]["source"]["transform"]
        assert source_transform["outputDimensions"]["t"] == expected

        # The spatial axes are unaffected by the time calibration.
        assert ng_json["dimensions"]["y"] == [0.5, "um"]
        assert ng_json["dimensions"]["x"] == [0.5, "um"]


def test_neuroglancer_state_keeps_a_bare_time_dimension_uncalibrated():
    """An image with no time calibration still declares a unity time scale."""
    sim = si_utils.get_sim_from_array(
        np.zeros((3, 1, 8, 8), dtype=np.uint16),
        dims=["t", "c", "y", "x"],
        scale={"y": 0.5, "x": 0.5},
        transform_key=METADATA_TRANSFORM_KEY,
    )

    ng_json = vis_utils.generate_neuroglancer_json(
        ome_zarr_paths=None,
        ome_zarr_urls=["zarr://http://localhost:8000/plain.ome.zarr"],
        sims=[sim],
        transform_key=METADATA_TRANSFORM_KEY,
    )

    assert ng_json["dimensions"]["t"] == [1.0, ""]
    assert ng_json["dimensions"]["c"] == [1, ""]
